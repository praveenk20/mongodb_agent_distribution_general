"""
Output Parser Node - Convert JSON to Natural Language

This node:
1. Takes query results (JSON/dict)
2. Calls LLM to generate user-friendly natural language response
3. Returns formatted answer
"""

import logging
from typing import Dict, Any

# Global instances (set by build_graph)
llm = None
config = None

logger = logging.getLogger(__name__)


def output_parser(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Parse query result into natural language
    
    Args:
        state: Current agent state with query_result
    
    Returns:
        Updated state with formatted query_result (natural language)
    """
    logger.info("📝 Output Parser: Converting results to natural language")
    
    try:
        # 1. Get query result
        query_result = state.get("query_result", "No data available")
        user_query = state["messages"][0].content if state.get("messages") else ""
        
        logger.info(f"Parsing result: {str(query_result)[:100]}...")
        
        # 2. Build output parser prompt
        from mongodb_agent.prompts import build_output_parser_prompt
        
        prompt = build_output_parser_prompt(
            user_query=user_query,
            query_result=str(query_result)
        )
        
        # 3. Call LLM to format response
        logger.info("🤖 Calling LLM to format response")
        logger.info(f"📤 LLM REQUEST PROMPT ({len(prompt)} chars):\n{prompt}")
        logger.info("=" * 80)
        full_response = ""
        for chunk in llm.stream(prompt):
            full_response += chunk.content
        
        logger.info(f"✅ Natural language response: {len(full_response)} chars")
        logger.info(f"📝 NATURAL LANGUAGE RESPONSE:\n{full_response}")
        
        # 4. Return formatted response
        return {
            "query_result": full_response
        }
    
    except Exception as e:
        logger.exception(f"❌ Output parser error: {e}")
        return {
            "query_result": f"Error formatting response: {str(e)}"
        }
